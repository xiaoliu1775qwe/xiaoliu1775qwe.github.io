<?php
$min_version = '8.0.0';
$current_version = PHP_VERSION;
if (!(function_exists('version_compare') ? version_compare($current_version, $min_version, '>=') : (function() use ($current_version, $min_version) {
    $current = explode('.', $current_version);
    $min = explode('.', $min_version);
    for ($i = 0; $i < 3; $i++) {
        $c = (int)($current[$i] ?? 0);
        $m = (int)($min[$i] ?? 0);
        if ($c > $m) return true;
        if ($c < $m) return false;
    }
    return true;
})())) {
    if (!headers_sent() && function_exists('header')) {
        header('HTTP/1.1 400 Bad Request');
        header('Content-Type: text/html; charset=utf-8');
    }
    die('<!DOCTYPE html>
<html>
<head>
    <title>PHP版本不兼容！</title>
    <style>
        body{font-family:Arial,sans-serif;background:#f8f9fa;margin:0;padding:20px;color:#343a40}
        .container{max-width:600px;margin:50px auto;padding:30px;background:#fff;border-radius:5px;box-shadow:0 0 10px rgba(0,0,0,0.1)}
        h1{color:#dc3545;margin-top:0}
        .version-info{background:#f8f9fa;padding:15px;border-radius:4px;margin:20px 0}
        .current{color:#dc3545;font-weight:700}
        .required{color:#28a745;font-weight:700}
        .copyright{text-align:center;margin-top:30px;color:#6c757d;font-size:14px}
    </style>
</head>
<body>
    <div class="container">
    <img src="https://www.kjcx1.top/kjcx1pro-API/Videof5642538.jpg" style="width:250px; height:120px;">
        <h1>⚠️PHP版本不兼容！</h1>
        <p>当前PHP版本: <span class="current">'.$current_version.'</span></p>
        <p>要求PHP版本: <span class="required">'.$min_version.'或更高</span></p>
        <p>请立刻升级你的PHP版本！</p>
        <div class="copyright">Copyright © 2023-'.date('Y').' 科技创想网络工作室</div>
    </div>
</body>
</html>');
}
$domain = $_SERVER['HTTP_HOST'];
$required_txt = "Domain='$domain';Login_program='kjcx1Pro api_login';Service_provider_website='app.kjcx2.top';country=CN;verification_key='87c7d61b77f9482c4ade83444e560c209a0e18ac8d171733f6b9d04832191ec26f85dbd7541c6ee7e810cfaf422e3c811fb289b304b9eca12f3e1b092c10f0c1'";
$txt_found = false;
$max_retries = 5;
$retry_delay = 3000;
for ($i = 0; $i < $max_retries; $i++) {
    $records = @dns_get_record($domain, DNS_TXT);
    foreach ((array)$records as $record) {
        if (isset($record['txt']) && trim($record['txt']) === trim($required_txt)) {
            $txt_found = true;
            break 2;
        }
    }
    if ($i < $max_retries - 1) {
        usleep($retry_delay);
    }
}
if (!$txt_found) {
    if (!headers_sent() && function_exists('header')) {
        header('HTTP/1.1 403 Forbidden');
        header('Content-Type: text/html; charset=utf-8');
    }
    die('<!DOCTYPE html>
<html>
<head>
    <title>域名签名验证失败！</title>
    <style>
        body{font-family:Arial,sans-serif;background:#f8f9fa;margin:0;padding:20px;color:#343a40}
        .container{max-width:600px;margin:50px auto;padding:30px;background:#fff;border-radius:5px;box-shadow:0 0 10px rgba(0,0,0,0.1)}
        h1{color:#dc3545;margin-top:0}
        .error{color:#dc3545;font-weight:700}
        pre{background:#f0f0f0;padding:10px;border-radius:4px;overflow-x:auto}
        .copyright{text-align:center;margin-top:30px;color:#6c757d;font-size:14px}
        .note{color:#6c757d;font-size:14px;margin-top:20px}
        .copy-btn{background-color:#28a745;color:#fff;padding:5px 10px;border:none;border-radius:4px;cursor:pointer}
        .copy-btn:hover{background-color:#218838}
    </style>
</head>
<body>
    <div class="container">
    <img src="https://www.kjcx1.top/kjcx1pro-API/Videof5642538.jpg" style="width:250px; height:120px;">
        <h1>⚠️域名签名验证失败！</h1>
        <p class="error">请确保已添加以下<strong>精确匹配</strong>的TXT记录：</p>
        <pre id="txt-record">'.$required_txt.'</pre>
        <button class="copy-btn" onclick="copyText()">复制记录</button>
        <p>域名: <strong>'.$domain.'</strong></p>
        <div class="note">
            <p>• DNS更改可能需要几分钟到几小时生效</p>
            <p>• 检查是否有多余空格或特殊字符</p>
            <p>• 确保记录类型是TXT</p>
        </div>
        <div class="copyright">Copyright © 2023-'.date('Y').' 科技创想网络工作室</div>
    </div>
    <script>
        function copyText() {
            var copyText = document.getElementById("txt-record");
            var range = document.createRange();
            range.selectNode(copyText);
            window.getSelection().addRange(range);
            try {
                document.execCommand("copy");
            } catch (err) {
                console.error("复制失败", err);
            }
            window.getSelection().removeAllRanges();
            alert("记录已复制到剪贴板！");
        }
    </script>
</body>
</html>');
}
?>
<?php
$serviceName = '';
$lnternet = '';
$keyData = '';

if (file_exists('config')) {
    $lines = file('config', FILE_IGNORE_NEW_LINES);
    $serviceName = $lines[0] ?? '';
    $lnternet = $lines[1] ?? '';
    $keyData = $lines[2] ?? '';
}
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo htmlspecialchars($serviceName); ?>—kjcx1 Pro专属用户中心</title>
    <style>
        body {
            font-family: 'Segoe UI', Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 20px;
            line-height: 1.6;
        }
        
        .container {
            width: 800px;
            margin: 20px auto 20px 20px;
            background: white;
            padding: 30px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        h1 {
            color: #0000FF;
            font-size: 24px;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .status {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .action-buttons {
            margin-top: 30px;
        }
      
        .btn {
            display: inline-block;
            padding: 8px 16px;
            background: #28a745;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            margin-right: 10px;
            font-size: 14px;
        }
        
        .btn:hover {
            background: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
    
            <img src="Videof5642538.jpg" style="width:250px; height:120px;">
        <h2><?php echo htmlspecialchars($serviceName); ?>—kjcx1 Pro专属用户中心</h2>
        
        <div class="status">
          <span class="">
        <div class="info-box">
        <div class="avatar"></div>
        <div class="user-info" id="user-info">
        </div>
        <div class="action-buttons">
        <h3>
       
             <br>------------------------------------------------------------------<br>
            <a href="/" class="btn">去首页</a>
            </h3>
         </div>
      </div>
   </div>
</div>   
    
 <?php
// 显示版权信息
$currentYear = date('Y');
echo "<h4>Copyright © 2023-" . $currentYear . " 科技创想网络工作室</h4>";
?>

    
     <script>
        function getCookie(name) {
            const cookieArray = document.cookie.split('; ');
            for (let i = 0; i < cookieArray.length; i++) {
                const cookiePair = cookieArray[i].split('=');
                if (cookiePair[0] === name) {
                    return decodeURIComponent(cookiePair[1]);
                }
            }
            return null;
        }

        function clearCookies() {
const cookiesToClear = ['email', 'registered_at', 'api', 'api_1', 'api_2', 'api_3', 'registered_at_api', 'email_api'];
            
            const domainParts = window.location.hostname.split('.');
            const domains = [
                '', 
                window.location.hostname, 
                ...(domainParts.length > 2 ? [`.${domainParts.slice(-2).join('.')}`] : []) 
            ].filter((value, index, self) => self.indexOf(value) === index); 
            
            const paths = ['', '/']; 
            
            cookiesToClear.forEach(name => {
                paths.forEach(path => {
                    domains.forEach(domain => {
                        let cookieString = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 GMT; path=${path}`;
                        if (domain) {
                            cookieString += `; domain=${domain}`;
                        }
                        document.cookie = cookieString;
                    });
                });
            });
            
         
            window.location.href = window.location.href.split('?')[0]; 
        }

        // 检测登录状态并显示信息
        const userInfoDiv = document.getElementById('user-info');
        const registeredAt = getCookie('registered_at');
        const email = getCookie('email');

        if (registeredAt && email) {
            // 如果用户已登录，显示用户信息
            userInfoDiv.innerHTML = `
                <p><strong>注册日期：</strong>${registeredAt}</p>
                <p><strong>邮箱：</strong>${email}</p>
                <button onclick="clearCookies()" class="btn">退出登录</button>
            `;
        } else {
            // 如果用户未登录，显示登录按钮
            userInfoDiv.innerHTML = `
                <p>您尚未登录</p>
               <button onclick="window.location.href='login.php'" class="btn">点击登录</button>
            `;
        }

  
        function triggerClick(button, url) {
     
            button.classList.add('btn-click');
            
    
            setTimeout(() => {
                button.classList.remove('btn-click');
            }, 400);
            
         
            if(url) {
                setTimeout(() => {
                    window.open(url);
                }, 200);
            }
        }
    </script>
</body>
</html>